﻿namespace Projeto_Livraria
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            gb_publicacao = new GroupBox();
            tb_1 = new TextBox();
            cb_1 = new ComboBox();
            cb_2 = new ComboBox();
            tb_2 = new TextBox();
            lbl_4 = new Label();
            dtp_publi_l = new DateTimePicker();
            tb_id_l = new TextBox();
            tb_titulo_l = new TextBox();
            tb_npag_l = new TextBox();
            tb_preco_l = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            lbl_3 = new Label();
            lbl_2 = new Label();
            lbl_1 = new Label();
            bt_registrar = new Button();
            Produtos = new TabControl();
            tabPage1 = new TabPage();
            bt_limpar = new Button();
            cb_escolha = new ComboBox();
            label11 = new Label();
            tabPage2 = new TabPage();
            cb_escolha2 = new ComboBox();
            label12 = new Label();
            dataGridView1 = new DataGridView();
            iDPDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            tituloPDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            npaginasPDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            datapubliPDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            precoPDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            publicacaoesBindingSource = new BindingSource(components);
            tabPage3 = new TabPage();
            tb_stock = new TextBox();
            label1 = new Label();
            tb_resultado3 = new TextBox();
            label18 = new Label();
            tb_resultado2 = new TextBox();
            label17 = new Label();
            bt_calcular = new Button();
            tb_valor2 = new TextBox();
            tb_valor1 = new TextBox();
            Extra = new Label();
            label15 = new Label();
            cb_escolha3 = new ComboBox();
            tb_resultado1 = new TextBox();
            Produto = new Label();
            label13 = new Label();
            contextMenuStrip1 = new ContextMenuStrip(components);
            gb_publicacao.SuspendLayout();
            Produtos.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)publicacaoesBindingSource).BeginInit();
            tabPage3.SuspendLayout();
            SuspendLayout();
            // 
            // gb_publicacao
            // 
            gb_publicacao.BackColor = Color.White;
            gb_publicacao.Controls.Add(tb_1);
            gb_publicacao.Controls.Add(cb_1);
            gb_publicacao.Controls.Add(cb_2);
            gb_publicacao.Controls.Add(tb_2);
            gb_publicacao.Controls.Add(lbl_4);
            gb_publicacao.Controls.Add(dtp_publi_l);
            gb_publicacao.Controls.Add(tb_id_l);
            gb_publicacao.Controls.Add(tb_titulo_l);
            gb_publicacao.Controls.Add(tb_npag_l);
            gb_publicacao.Controls.Add(tb_preco_l);
            gb_publicacao.Controls.Add(label9);
            gb_publicacao.Controls.Add(label8);
            gb_publicacao.Controls.Add(label7);
            gb_publicacao.Controls.Add(label6);
            gb_publicacao.Controls.Add(label5);
            gb_publicacao.Controls.Add(label4);
            gb_publicacao.Controls.Add(lbl_3);
            gb_publicacao.Controls.Add(lbl_2);
            gb_publicacao.Controls.Add(lbl_1);
            gb_publicacao.Font = new Font("Segoe UI Symbol", 10F);
            gb_publicacao.Location = new Point(96, 86);
            gb_publicacao.Name = "gb_publicacao";
            gb_publicacao.Size = new Size(1435, 570);
            gb_publicacao.TabIndex = 0;
            gb_publicacao.TabStop = false;
            gb_publicacao.Enter += gb_publicacao_Enter;
            // 
            // tb_1
            // 
            tb_1.BackColor = Color.White;
            tb_1.BorderStyle = BorderStyle.FixedSingle;
            tb_1.ForeColor = Color.MidnightBlue;
            tb_1.Location = new Point(995, 92);
            tb_1.Name = "tb_1";
            tb_1.Size = new Size(300, 34);
            tb_1.TabIndex = 19;
            // 
            // cb_1
            // 
            cb_1.BackColor = Color.White;
            cb_1.FlatStyle = FlatStyle.Popup;
            cb_1.ForeColor = Color.MidnightBlue;
            cb_1.FormattingEnabled = true;
            cb_1.Items.AddRange(new object[] { "9", "12", "14", "16", "18" });
            cb_1.Location = new Point(995, 167);
            cb_1.Name = "cb_1";
            cb_1.Size = new Size(300, 36);
            cb_1.TabIndex = 18;
            cb_1.Text = "Selecione";
            // 
            // cb_2
            // 
            cb_2.BackColor = Color.White;
            cb_2.FlatStyle = FlatStyle.Popup;
            cb_2.ForeColor = Color.MidnightBlue;
            cb_2.FormattingEnabled = true;
            cb_2.Items.AddRange(new object[] { "Terror", "Comédia", "Romance", "Poesia", "Suspense", "Documentario" });
            cb_2.Location = new Point(995, 243);
            cb_2.Name = "cb_2";
            cb_2.Size = new Size(300, 36);
            cb_2.TabIndex = 17;
            cb_2.Text = "Selecione";
            // 
            // tb_2
            // 
            tb_2.BackColor = Color.White;
            tb_2.BorderStyle = BorderStyle.FixedSingle;
            tb_2.ForeColor = Color.MidnightBlue;
            tb_2.Location = new Point(995, 324);
            tb_2.Name = "tb_2";
            tb_2.Size = new Size(300, 34);
            tb_2.TabIndex = 16;
            // 
            // lbl_4
            // 
            lbl_4.Location = new Point(684, 327);
            lbl_4.Name = "lbl_4";
            lbl_4.Size = new Size(247, 25);
            lbl_4.TabIndex = 15;
            lbl_4.Text = "Margem de Lucro";
            lbl_4.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dtp_publi_l
            // 
            dtp_publi_l.CalendarForeColor = Color.MidnightBlue;
            dtp_publi_l.CalendarMonthBackground = Color.White;
            dtp_publi_l.CalendarTitleForeColor = Color.MidnightBlue;
            dtp_publi_l.CalendarTrailingForeColor = SystemColors.GradientInactiveCaption;
            dtp_publi_l.Location = new Point(340, 241);
            dtp_publi_l.Name = "dtp_publi_l";
            dtp_publi_l.Size = new Size(300, 34);
            dtp_publi_l.TabIndex = 14;
            // 
            // tb_id_l
            // 
            tb_id_l.BackColor = Color.White;
            tb_id_l.BorderStyle = BorderStyle.FixedSingle;
            tb_id_l.Enabled = false;
            tb_id_l.ForeColor = Color.MidnightBlue;
            tb_id_l.Location = new Point(340, 92);
            tb_id_l.Name = "tb_id_l";
            tb_id_l.Size = new Size(300, 34);
            tb_id_l.TabIndex = 13;
            // 
            // tb_titulo_l
            // 
            tb_titulo_l.BackColor = Color.White;
            tb_titulo_l.BorderStyle = BorderStyle.FixedSingle;
            tb_titulo_l.ForeColor = Color.MidnightBlue;
            tb_titulo_l.Location = new Point(340, 167);
            tb_titulo_l.Name = "tb_titulo_l";
            tb_titulo_l.Size = new Size(300, 34);
            tb_titulo_l.TabIndex = 20;
            // 
            // tb_npag_l
            // 
            tb_npag_l.BackColor = Color.White;
            tb_npag_l.BorderStyle = BorderStyle.FixedSingle;
            tb_npag_l.ForeColor = Color.MidnightBlue;
            tb_npag_l.Location = new Point(340, 322);
            tb_npag_l.Name = "tb_npag_l";
            tb_npag_l.Size = new Size(300, 34);
            tb_npag_l.TabIndex = 21;
            // 
            // tb_preco_l
            // 
            tb_preco_l.BackColor = Color.White;
            tb_preco_l.BorderStyle = BorderStyle.FixedSingle;
            tb_preco_l.ForeColor = Color.MidnightBlue;
            tb_preco_l.Location = new Point(340, 398);
            tb_preco_l.Name = "tb_preco_l";
            tb_preco_l.Size = new Size(300, 34);
            tb_preco_l.TabIndex = 9;
            tb_preco_l.TextChanged += tb_preco_l_TextChanged;
            // 
            // label9
            // 
            label9.Location = new Point(96, 401);
            label9.Name = "label9";
            label9.Size = new Size(205, 25);
            label9.TabIndex = 8;
            label9.Text = "Preço";
            label9.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            label8.Location = new Point(96, 324);
            label8.Name = "label8";
            label8.Size = new Size(205, 25);
            label8.TabIndex = 7;
            label8.Text = "Nº de Páginas";
            label8.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            label7.Location = new Point(96, 246);
            label7.Name = "label7";
            label7.Size = new Size(205, 25);
            label7.TabIndex = 6;
            label7.Text = "Data da Publicação";
            label7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            label6.Location = new Point(96, 171);
            label6.Name = "label6";
            label6.Size = new Size(205, 25);
            label6.TabIndex = 5;
            label6.Text = "Título";
            label6.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            label5.Location = new Point(96, 95);
            label5.Name = "label5";
            label5.Size = new Size(205, 25);
            label5.TabIndex = 4;
            label5.Text = "ID";
            label5.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(146, 298);
            label4.Name = "label4";
            label4.Size = new Size(0, 28);
            label4.TabIndex = 3;
            // 
            // lbl_3
            // 
            lbl_3.Location = new Point(684, 246);
            lbl_3.Name = "lbl_3";
            lbl_3.Size = new Size(247, 25);
            lbl_3.TabIndex = 2;
            lbl_3.Text = "Categoria";
            lbl_3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lbl_2
            // 
            lbl_2.Location = new Point(684, 170);
            lbl_2.Name = "lbl_2";
            lbl_2.Size = new Size(247, 25);
            lbl_2.TabIndex = 1;
            lbl_2.Text = "Faixa Etária";
            lbl_2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // lbl_1
            // 
            lbl_1.Location = new Point(684, 95);
            lbl_1.Name = "lbl_1";
            lbl_1.Size = new Size(247, 25);
            lbl_1.TabIndex = 0;
            lbl_1.Text = "Autor";
            lbl_1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // bt_registrar
            // 
            bt_registrar.BackColor = Color.Turquoise;
            bt_registrar.FlatStyle = FlatStyle.Flat;
            bt_registrar.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold);
            bt_registrar.ForeColor = Color.White;
            bt_registrar.Location = new Point(395, 711);
            bt_registrar.Name = "bt_registrar";
            bt_registrar.Size = new Size(266, 64);
            bt_registrar.TabIndex = 20;
            bt_registrar.Text = "Registrar";
            bt_registrar.UseVisualStyleBackColor = false;
            bt_registrar.Click += bt_registrar_Click;
            // 
            // Produtos
            // 
            Produtos.Controls.Add(tabPage1);
            Produtos.Controls.Add(tabPage2);
            Produtos.Controls.Add(tabPage3);
            Produtos.Location = new Point(-1, 23);
            Produtos.Name = "Produtos";
            Produtos.SelectedIndex = 0;
            Produtos.Size = new Size(1638, 901);
            Produtos.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.White;
            tabPage1.BorderStyle = BorderStyle.Fixed3D;
            tabPage1.Controls.Add(bt_limpar);
            tabPage1.Controls.Add(bt_registrar);
            tabPage1.Controls.Add(cb_escolha);
            tabPage1.Controls.Add(label11);
            tabPage1.Controls.Add(gb_publicacao);
            tabPage1.Font = new Font("Arial", 9F, FontStyle.Bold);
            tabPage1.Location = new Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1630, 863);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Registrar";
            // 
            // bt_limpar
            // 
            bt_limpar.BackColor = Color.Turquoise;
            bt_limpar.FlatStyle = FlatStyle.Flat;
            bt_limpar.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold);
            bt_limpar.ForeColor = Color.White;
            bt_limpar.Location = new Point(995, 711);
            bt_limpar.Name = "bt_limpar";
            bt_limpar.Size = new Size(266, 64);
            bt_limpar.TabIndex = 21;
            bt_limpar.Text = "Limpar";
            bt_limpar.UseVisualStyleBackColor = false;
            bt_limpar.Click += bt_limpar_Click;
            // 
            // cb_escolha
            // 
            cb_escolha.BackColor = SystemColors.Window;
            cb_escolha.FlatStyle = FlatStyle.Popup;
            cb_escolha.Font = new Font("Segoe UI Symbol", 10F);
            cb_escolha.ForeColor = Color.MidnightBlue;
            cb_escolha.FormattingEnabled = true;
            cb_escolha.Items.AddRange(new object[] { "Livro", "Revista", "Jornal" });
            cb_escolha.Location = new Point(838, 31);
            cb_escolha.Name = "cb_escolha";
            cb_escolha.Size = new Size(354, 36);
            cb_escolha.TabIndex = 2;
            cb_escolha.Text = "Selecione";
            cb_escolha.SelectedIndexChanged += cb_escolha_SelectedIndexChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Symbol", 10F);
            label11.Location = new Point(358, 34);
            label11.Name = "label11";
            label11.Size = new Size(449, 28);
            label11.TabIndex = 1;
            label11.Text = "Que tipo de Publicação deseja adicionar a livraria?";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.White;
            tabPage2.Controls.Add(cb_escolha2);
            tabPage2.Controls.Add(label12);
            tabPage2.Controls.Add(dataGridView1);
            tabPage2.Font = new Font("Arial", 9F, FontStyle.Bold);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1630, 863);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Listar";
            // 
            // cb_escolha2
            // 
            cb_escolha2.Font = new Font("Segoe UI Symbol", 10F);
            cb_escolha2.ForeColor = Color.MidnightBlue;
            cb_escolha2.FormattingEnabled = true;
            cb_escolha2.Items.AddRange(new object[] { "Livro", "Revista", "Jornal", "Todos" });
            cb_escolha2.Location = new Point(803, 35);
            cb_escolha2.Name = "cb_escolha2";
            cb_escolha2.Size = new Size(325, 36);
            cb_escolha2.TabIndex = 2;
            cb_escolha2.Text = "Selecione";
            cb_escolha2.SelectedIndexChanged += cb_escolha2_SelectedIndexChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI Symbol", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Black;
            label12.Location = new Point(451, 38);
            label12.Name = "label12";
            label12.Size = new Size(331, 28);
            label12.TabIndex = 1;
            label12.Text = "Que tipo de Publicação deseja listar?";
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { iDPDataGridViewTextBoxColumn, tituloPDataGridViewTextBoxColumn, npaginasPDataGridViewTextBoxColumn, datapubliPDataGridViewTextBoxColumn, precoPDataGridViewTextBoxColumn });
            dataGridView1.DataSource = publicacaoesBindingSource;
            dataGridView1.GridColor = Color.White;
            dataGridView1.Location = new Point(86, 103);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.ShowCellToolTips = false;
            dataGridView1.Size = new Size(1457, 681);
            dataGridView1.TabIndex = 0;
            // 
            // iDPDataGridViewTextBoxColumn
            // 
            iDPDataGridViewTextBoxColumn.DataPropertyName = "IDP";
            iDPDataGridViewTextBoxColumn.HeaderText = "ID";
            iDPDataGridViewTextBoxColumn.MinimumWidth = 8;
            iDPDataGridViewTextBoxColumn.Name = "iDPDataGridViewTextBoxColumn";
            iDPDataGridViewTextBoxColumn.Width = 200;
            // 
            // tituloPDataGridViewTextBoxColumn
            // 
            tituloPDataGridViewTextBoxColumn.DataPropertyName = "tituloP";
            tituloPDataGridViewTextBoxColumn.HeaderText = "Título";
            tituloPDataGridViewTextBoxColumn.MinimumWidth = 8;
            tituloPDataGridViewTextBoxColumn.Name = "tituloPDataGridViewTextBoxColumn";
            tituloPDataGridViewTextBoxColumn.Width = 200;
            // 
            // npaginasPDataGridViewTextBoxColumn
            // 
            npaginasPDataGridViewTextBoxColumn.DataPropertyName = "npaginasP";
            npaginasPDataGridViewTextBoxColumn.HeaderText = "Nº de Páginas";
            npaginasPDataGridViewTextBoxColumn.MinimumWidth = 8;
            npaginasPDataGridViewTextBoxColumn.Name = "npaginasPDataGridViewTextBoxColumn";
            npaginasPDataGridViewTextBoxColumn.Width = 200;
            // 
            // datapubliPDataGridViewTextBoxColumn
            // 
            datapubliPDataGridViewTextBoxColumn.DataPropertyName = "datapubliP";
            datapubliPDataGridViewTextBoxColumn.HeaderText = "Data de Publicação";
            datapubliPDataGridViewTextBoxColumn.MinimumWidth = 8;
            datapubliPDataGridViewTextBoxColumn.Name = "datapubliPDataGridViewTextBoxColumn";
            datapubliPDataGridViewTextBoxColumn.Width = 200;
            // 
            // precoPDataGridViewTextBoxColumn
            // 
            precoPDataGridViewTextBoxColumn.DataPropertyName = "precoP";
            precoPDataGridViewTextBoxColumn.HeaderText = "Preço";
            precoPDataGridViewTextBoxColumn.MinimumWidth = 8;
            precoPDataGridViewTextBoxColumn.Name = "precoPDataGridViewTextBoxColumn";
            precoPDataGridViewTextBoxColumn.Width = 200;
            // 
            // publicacaoesBindingSource
            // 
            publicacaoesBindingSource.DataSource = typeof(Publicacoes);
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.White;
            tabPage3.BorderStyle = BorderStyle.FixedSingle;
            tabPage3.Controls.Add(tb_stock);
            tabPage3.Controls.Add(label1);
            tabPage3.Controls.Add(tb_resultado3);
            tabPage3.Controls.Add(label18);
            tabPage3.Controls.Add(tb_resultado2);
            tabPage3.Controls.Add(label17);
            tabPage3.Controls.Add(bt_calcular);
            tabPage3.Controls.Add(tb_valor2);
            tabPage3.Controls.Add(tb_valor1);
            tabPage3.Controls.Add(Extra);
            tabPage3.Controls.Add(label15);
            tabPage3.Controls.Add(cb_escolha3);
            tabPage3.Controls.Add(tb_resultado1);
            tabPage3.Controls.Add(Produto);
            tabPage3.Controls.Add(label13);
            tabPage3.Font = new Font("Arial", 9F, FontStyle.Bold);
            tabPage3.Location = new Point(4, 34);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(1630, 863);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Calcular";
            // 
            // tb_stock
            // 
            tb_stock.BorderStyle = BorderStyle.FixedSingle;
            tb_stock.Font = new Font("Segoe UI Symbol", 10F);
            tb_stock.ForeColor = Color.MidnightBlue;
            tb_stock.Location = new Point(717, 305);
            tb_stock.Name = "tb_stock";
            tb_stock.Size = new Size(313, 34);
            tb_stock.TabIndex = 14;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe UI Symbol", 10F);
            label1.Location = new Point(467, 308);
            label1.Name = "label1";
            label1.Size = new Size(227, 25);
            label1.TabIndex = 13;
            label1.Text = "Quantidade em Stock";
            label1.TextAlign = ContentAlignment.MiddleRight;
            // 
            // tb_resultado3
            // 
            tb_resultado3.BorderStyle = BorderStyle.FixedSingle;
            tb_resultado3.Font = new Font("Segoe UI Symbol", 10F);
            tb_resultado3.ForeColor = Color.MidnightBlue;
            tb_resultado3.Location = new Point(1253, 641);
            tb_resultado3.Name = "tb_resultado3";
            tb_resultado3.Size = new Size(182, 34);
            tb_resultado3.TabIndex = 12;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI Symbol", 10F);
            label18.Location = new Point(1074, 644);
            label18.Name = "label18";
            label18.Size = new Size(145, 28);
            label18.TabIndex = 11;
            label18.Text = "Lucro por taxas";
            // 
            // tb_resultado2
            // 
            tb_resultado2.BorderStyle = BorderStyle.FixedSingle;
            tb_resultado2.Font = new Font("Segoe UI Symbol", 10F);
            tb_resultado2.ForeColor = Color.MidnightBlue;
            tb_resultado2.Location = new Point(814, 638);
            tb_resultado2.Name = "tb_resultado2";
            tb_resultado2.Size = new Size(182, 34);
            tb_resultado2.TabIndex = 10;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI Symbol", 10F);
            label17.Location = new Point(579, 640);
            label17.Name = "label17";
            label17.Size = new Size(229, 28);
            label17.TabIndex = 9;
            label17.Text = "Lucro p/venda Individual";
            // 
            // bt_calcular
            // 
            bt_calcular.BackColor = Color.Turquoise;
            bt_calcular.FlatStyle = FlatStyle.Flat;
            bt_calcular.Font = new Font("Segoe UI Symbol", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            bt_calcular.ForeColor = Color.White;
            bt_calcular.Location = new Point(630, 460);
            bt_calcular.Name = "bt_calcular";
            bt_calcular.Size = new Size(326, 64);
            bt_calcular.TabIndex = 8;
            bt_calcular.Text = "Calcular";
            bt_calcular.UseVisualStyleBackColor = false;
            bt_calcular.Click += bt_calcular_Click;
            // 
            // tb_valor2
            // 
            tb_valor2.BorderStyle = BorderStyle.FixedSingle;
            tb_valor2.Font = new Font("Segoe UI Symbol", 10F);
            tb_valor2.ForeColor = Color.MidnightBlue;
            tb_valor2.Location = new Point(717, 240);
            tb_valor2.Name = "tb_valor2";
            tb_valor2.Size = new Size(313, 34);
            tb_valor2.TabIndex = 7;
            // 
            // tb_valor1
            // 
            tb_valor1.BorderStyle = BorderStyle.FixedSingle;
            tb_valor1.Font = new Font("Segoe UI Symbol", 10F);
            tb_valor1.ForeColor = Color.MidnightBlue;
            tb_valor1.Location = new Point(717, 177);
            tb_valor1.Name = "tb_valor1";
            tb_valor1.Size = new Size(313, 34);
            tb_valor1.TabIndex = 6;
            // 
            // Extra
            // 
            Extra.Font = new Font("Segoe UI Symbol", 10F);
            Extra.Location = new Point(552, 243);
            Extra.Name = "Extra";
            Extra.Size = new Size(133, 25);
            Extra.TabIndex = 5;
            Extra.Text = "Taxas Extras";
            Extra.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label15
            // 
            label15.Font = new Font("Segoe UI Symbol", 10F);
            label15.Location = new Point(528, 180);
            label15.Name = "label15";
            label15.Size = new Size(157, 25);
            label15.TabIndex = 4;
            label15.Text = "Valor Base";
            label15.TextAlign = ContentAlignment.MiddleRight;
            // 
            // cb_escolha3
            // 
            cb_escolha3.BackColor = SystemColors.Window;
            cb_escolha3.FlatStyle = FlatStyle.Popup;
            cb_escolha3.Font = new Font("Segoe UI Symbol", 10F);
            cb_escolha3.ForeColor = Color.MidnightBlue;
            cb_escolha3.FormattingEnabled = true;
            cb_escolha3.Location = new Point(717, 117);
            cb_escolha3.Name = "cb_escolha3";
            cb_escolha3.Size = new Size(313, 36);
            cb_escolha3.TabIndex = 3;
            cb_escolha3.Text = "Selecione";
            cb_escolha3.SelectedIndexChanged += cb_escolha3_SelectedIndexChanged;
            // 
            // tb_resultado1
            // 
            tb_resultado1.BorderStyle = BorderStyle.FixedSingle;
            tb_resultado1.Font = new Font("Segoe UI Symbol", 10F);
            tb_resultado1.ForeColor = Color.MidnightBlue;
            tb_resultado1.Location = new Point(297, 637);
            tb_resultado1.Name = "tb_resultado1";
            tb_resultado1.Size = new Size(182, 34);
            tb_resultado1.TabIndex = 2;
            // 
            // Produto
            // 
            Produto.Font = new Font("Segoe UI Symbol", 10F);
            Produto.Location = new Point(552, 120);
            Produto.Name = "Produto";
            Produto.Size = new Size(133, 25);
            Produto.TabIndex = 1;
            Produto.Text = "Publicação";
            Produto.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Symbol", 10F);
            label13.Location = new Point(153, 641);
            label13.Name = "label13";
            label13.Size = new Size(109, 28);
            label13.TabIndex = 0;
            label13.Text = "Lucro Total";
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(24, 24);
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(1636, 918);
            Controls.Add(Produtos);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Gestão de Publicações";
            Load += Form1_Load;
            gb_publicacao.ResumeLayout(false);
            gb_publicacao.PerformLayout();
            Produtos.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)publicacaoesBindingSource).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gb_publicacao;
        private Label lbl_1;
        private DateTimePicker dtp_publi_l;
        private TextBox tb_id_l;
        private TextBox tb_titulo_l;
        private TextBox tb_npag_l;
        private TextBox tb_preco_l;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label lbl_3;
        private Label lbl_2;
        private TextBox tb_1;
        private ComboBox cb_1;
        private ComboBox cb_2;
        private TextBox tb_2;
        private Label lbl_4;
        private Button bt_registrar;
        private TabControl Produtos;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private ComboBox cb_escolha;
        private Label label11;
        private ComboBox cb_escolha2;
        private Label label12;
        private DataGridView dataGridView1;
        private TabPage tabPage3;
        private Button bt_calcular;
        private TextBox tb_valor2;
        private TextBox tb_valor1;
        private Label Extra;
        private Label label15;
        private ComboBox cb_escolha3;
        private TextBox tb_resultado1;
        private Label Produto;
        private Label label13;
        private ContextMenuStrip contextMenuStrip1;
        private TextBox tb_resultado3;
        private Label label18;
        private TextBox tb_resultado2;
        private Label label17;
        private BindingSource publicacaoesBindingSource;
        private DataGridViewTextBoxColumn iDPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn tituloPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn npaginasPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn datapubliPDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn precoPDataGridViewTextBoxColumn;
        private Button bt_limpar;
        private TextBox tb_stock;
        private Label label1;
    }
}
