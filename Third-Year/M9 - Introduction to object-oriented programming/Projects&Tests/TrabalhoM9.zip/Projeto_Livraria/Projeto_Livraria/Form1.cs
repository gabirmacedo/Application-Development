using static Projeto_Livraria.Livro;


namespace Projeto_Livraria
{
    public partial class Form1 : Form
    {
        private List<Publicacoes> publicacoes = new List<Publicacoes>();
        private int id = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void cb_escolha_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_escolha.SelectedItem.ToString() == "Livro")
            {
                gb_publicacao.Enabled = true;
                lbl_1.Text = "Autor";
                lbl_4.Text = "Margem de Lucro";
                lbl_2.Text = "Faixa Et�ria";
                lbl_3.Text = "Categoria";

                cb_1.Items.Clear();
                cb_1.Text = "Selecione";
                cb_1.Items.Add("9");
                cb_1.Items.Add("12");
                cb_1.Items.Add("14");
                cb_1.Items.Add("16");
                cb_1.Items.Add("18");

                cb_2.Items.Clear();
                cb_2.Text = "Selecione";
                cb_2.Items.Add("Terror");
                cb_2.Items.Add("Romance");
                cb_2.Items.Add("Fic��o");
                cb_2.Items.Add("Poesia");
                cb_2.Items.Add("Magia");
                cb_2.Items.Add("A��o");
                cb_2.Items.Add("Biografia");
            }
            else if (cb_escolha.SelectedItem.ToString() == "Revista")
            {
                gb_publicacao.Enabled = true;
                lbl_1.Text = "Diretor";
                lbl_4.Text = "N� Edi��o";
                lbl_3.Text = "Taxa";
                lbl_2.Text = "Periodicidade";

                cb_1.Items.Clear();
                cb_1.Text = "Selecione";
                cb_1.Items.Add("Semanal");
                cb_1.Items.Add("Mensal");
                cb_1.Items.Add("Anual");

                cb_2.Items.Clear();
                cb_2.Text = "Selecione";
                cb_2.Items.Add("Sim");
                cb_2.Items.Add("N�o");

            }
            else if (cb_escolha.SelectedItem.ToString() == "Jornal")
            {
                gb_publicacao.Enabled = true;
                lbl_1.Text = "Diretor";
                lbl_4.Text = "N� Edi��o";
                lbl_3.Text = "Tem Caderno Especial?";
                lbl_2.Text = "Periodicidade";

                cb_1.Items.Clear();
                cb_1.Text = "Selecione";
                cb_1.Items.Add("Semanal");
                cb_1.Items.Add("Mensal");
                cb_1.Items.Add("Anual");

                cb_2.Items.Clear();
                cb_2.Text = "Selecione";
                cb_2.Items.Add("Sim");
                cb_2.Items.Add("N�o");
            }

        }
        private void bt_registrar_Click(object sender, EventArgs e)
        {
            if (cb_escolha.SelectedItem == null)
            {
                MessageBox.Show("Selecione o tipo de publica��o.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrEmpty(tb_titulo_l.Text) ||
                string.IsNullOrEmpty(tb_npag_l.Text) || string.IsNullOrEmpty(tb_preco_l.Text) ||
                string.IsNullOrEmpty(tb_1.Text) || string.IsNullOrEmpty(tb_2.Text) ||
                cb_1.SelectedItem == null || cb_2.SelectedItem == null)
            {
                MessageBox.Show("Preencha todos os campos obrigat�rios.");
                return;
            }
            if (!int.TryParse(tb_npag_l.Text, out int numPaginas) || numPaginas <= 0)
            {
                MessageBox.Show("O n�mero de p�ginas deve ser um valor inteiro v�lido e maior que zero.", "Erro de Valida��o", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_npag_l.Focus();
                return;
            }

            if (!double.TryParse(tb_preco_l.Text, out double preco) || preco < 0)
            {
                MessageBox.Show("O pre�o deve ser um valor num�rico v�lido.", "Erro de Valida��o", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_preco_l.Focus();
                return;
            }

            string tipoPublicacao = cb_escolha.SelectedItem.ToString();

            if (cb_escolha.SelectedItem.ToString() == "Livro")
            {
                if (!double.TryParse(tb_2.Text, out double margemLucro))
                {
                    MessageBox.Show("A margem de lucro deve ser um valor num�rico v�lido.", "Erro de Valida��o", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_2.Focus();
                    return;
                }

                Livro livro = new Livro();
                livro.IDP = id;
                livro.tituloP = tb_titulo_l.Text;
                livro.npaginasP = int.Parse(tb_npag_l.Text);
                livro.datapubliP = dtp_publi_l.Value.ToShortDateString();
                livro.precoP = double.Parse(tb_preco_l.Text);

                livro.autorP = tb_1.Text;
                livro.faixaetP = int.Parse(cb_1.SelectedItem.ToString());
                livro.categoriaP = cb_2.SelectedItem.ToString();
                livro.margemlucroP = (double)Convert.ToDecimal(tb_2.Text);

                publicacoes.Add(livro);

                cb_escolha3.Items.Add(livro);
            }
            else if (cb_escolha.SelectedItem.ToString() == "Revista")
            {
                if (!int.TryParse(tb_2.Text, out int numEdicao))
                {
                    MessageBox.Show("O n�mero da edi��o deve ser um valor inteiro v�lido.", "Erro de Valida��o", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_2.Focus();
                    return;
                }
                Revista revista = new Revista();
                revista.IDP = id;
                revista.tituloP = tb_titulo_l.Text;
                revista.npaginasP = int.Parse(tb_npag_l.Text);
                revista.datapubliP = dtp_publi_l.Value.ToShortDateString();
                revista.precoP = double.Parse(tb_preco_l.Text);

                revista.diretorP = tb_1.Text;
                revista.periodicidadeP = cb_2.SelectedItem.ToString();
                if (cb_1.SelectedItem.ToString() == "Sim")
                {
                    revista.taxaP = 1;
                }
                else
                {
                    revista.taxaP = 0;
                }
                revista.nedicaoP = int.Parse(tb_2.Text);

                publicacoes.Add(revista);

                cb_escolha3.Items.Add(revista);
            }
            else if (cb_escolha.SelectedItem.ToString() == "Jornal")
            {
                Jornal jornal = new Jornal();
                jornal.IDP = id;
                jornal.tituloP = tb_titulo_l.Text;
                jornal.npaginasP = int.Parse(tb_npag_l.Text);
                jornal.datapubliP = dtp_publi_l.Value.ToShortDateString();
                jornal.precoP = double.Parse(tb_preco_l.Text);

                jornal.diretorP = tb_1.Text;
                jornal.periodicidadeP = cb_1.SelectedItem.ToString();
                jornal.temcadernoespecialP = (cb_2.SelectedItem.ToString() == "Sim") ? 1 : 0;

                publicacoes.Add(jornal);

                cb_escolha3.Items.Add(jornal);
            }

            id++;
            tb_id_l.Text = id.ToString();

            tb_titulo_l.Clear();
            tb_npag_l.Clear();
            tb_preco_l.Clear();
            tb_1.Clear();
            tb_2.Clear();
            cb_2.SelectedIndex = -1;
            cb_1.SelectedIndex = -1;
            cb_1.Text = "Selecione";
            cb_2.Text = "Selecione";

        }

        private void cb_escolha2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_escolha2.SelectedItem == null) return;

            string tipoSelecionado = cb_escolha2.SelectedItem.ToString();
            List<Publicacoes> listaFiltrada = new List<Publicacoes>();

            if (tipoSelecionado == "Livro")
            {
                foreach (var pub in publicacoes)
                {
                    if (pub is Livro) listaFiltrada.Add(pub);
                }
            }
            else if (tipoSelecionado == "Revista")
            {
                foreach (var pub in publicacoes)
                {
                    if (pub is Revista) listaFiltrada.Add(pub);
                }
            }
            else if (tipoSelecionado == "Jornal")
            {
                foreach (var pub in publicacoes)
                {
                    if (pub is Jornal) listaFiltrada.Add(pub);
                }
            }
            else
            {
                listaFiltrada = publicacoes;
            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = listaFiltrada;
        }

        private void bt_limpar_Click(object sender, EventArgs e)
        {
            tb_titulo_l.Clear();
            tb_npag_l.Clear();
            tb_preco_l.Clear();
            tb_1.Clear();
            tb_2.Clear();
            cb_2.SelectedIndex = -1;
            cb_1.SelectedIndex = -1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tb_id_l.Text = id.ToString();
            gb_publicacao.Enabled = false;

        }

        private void gb_publicacao_Enter(object sender, EventArgs e)
        {

        }

        private void lbl_3_Click(object sender, EventArgs e)
        {

        }

        private void cb_escolha3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_escolha3.SelectedItem != null)
            {
                Publicacoes pub = (Publicacoes)cb_escolha3.SelectedItem;

                tb_valor1.Text = pub.precoP.ToString();
                if (pub is Livro livro)
                {
                    tb_valor2.Text = livro.margemlucroP.ToString();
                }
                else if (pub is Revista revista)
                {
                    tb_valor2.Text = revista.nedicaoP.ToString();
                }
                else if (pub is Jornal jornal)
                {
                    tb_valor2.Text = jornal.temcadernoespecialP.ToString();
                }
            }
        }

        private void bt_calcular_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_valor1.Text) ||
                string.IsNullOrWhiteSpace(tb_valor2.Text) ||
                string.IsNullOrWhiteSpace(tb_stock.Text))
            {
                MessageBox.Show("Preencha todos os campos necess�rios para o c�lculo.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!double.TryParse(tb_valor1.Text, out double val1) ||
    !double.TryParse(tb_valor2.Text, out double val2) ||
    !int.TryParse(tb_stock.Text, out int stock))
            {
                MessageBox.Show("Certifique-se de que os valores s�o v�lidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double lucro = val1 + val2;
            tb_resultado2.Text = lucro.ToString("F2");
            tb_resultado1.Text = (lucro * stock).ToString("F2");
            tb_resultado3.Text = (val2 * stock).ToString("F2");

        }

        private void tb_preco_l_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
