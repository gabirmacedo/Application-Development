namespace Projeto_Livraria
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }

    public class Publicacoes
    {
        private int ID;
        private string titulo;
        private int npaginas;
        private string datapubli;
        private double preco;

        public int IDP
        {
            get { return ID; }
            set { ID = value; }
        }
        public string tituloP
        {
            get { return titulo; }
            set { titulo = value; }
        }
        public int npaginasP
        {
            get { return npaginas; }
            set { npaginas = value; }
        }
        public string datapubliP
        {
            get { return datapubli; }
            set { datapubli = value; }
        }
        public double precoP
        {
            get { return preco; }
            set { preco = value; }
        }
        public virtual double CalcularPrecoFinal()
        {
            return preco;
        }
        public override string ToString()
        {
            return tituloP;     
        }
    }

    public class Livro : Publicacoes
    {
        private string autor;
        private int faixaet;
        private string categoria;
        private double margemlucro;

        public string autorP
        {
            get { return autor; }
            set { autor = value; }
        }
        public int faixaetP
        {
            get { return faixaet; }
            set { faixaet = value; }
        }
        public string categoriaP
        {
            get { return categoria; }
            set { categoria = value; }
        }
        public double margemlucroP
        {
            get { return margemlucro; }
            set { margemlucro = value; }
        }
        public override double CalcularPrecoFinal()
        {
            return precoP * (1 + margemlucroP);
        }
        public override string ToString()
        {
            return tituloP;
        }
    }

    public class Revista : Publicacoes
    {
        private string diretor;
        private int nedicao;
        private double taxa;
        private string periodicidade;

        public string diretorP
        {
            get { return diretor; }
            set { diretor = value; }
        }
        public int nedicaoP
        {
            get { return nedicao; }
            set { nedicao = value; }
        }
        public double taxaP
        {
            get { return taxa; }
            set { taxa = value; }
        }
        public string periodicidadeP
        {
            get { return periodicidade; }
            set { periodicidade = value; }
        }
        public override double CalcularPrecoFinal()
        {
            return precoP + taxaP;
        }
        public override string ToString()
        {
            return tituloP;
        }
    }

    public class Jornal : Publicacoes
    {
        private string diretor;
        private int nedicao;
        private string periodicidade;
        private double temcadernoespecial;

        public string diretorP
        {
            get { return diretor; }
            set { diretor = value; }
        }
        public int nedicaoP
        {
            get { return nedicao; }
            set { nedicao = value; }
        }
        public string periodicidadeP
        {
            get { return periodicidade; }
            set { periodicidade = value; }
        }
        public double temcadernoespecialP
        {
            get { return temcadernoespecial; }
            set { temcadernoespecial = value; }
        }
        public override double CalcularPrecoFinal()
        {
            double PrecoFinal = precoP;

            if (temcadernoespecialP == 1)
            {
                int extra = 2; // Adiciona R$ 2,00 ao preço se houver caderno especial
                PrecoFinal = precoP + extra;
            }
            return PrecoFinal;
        }
        public override string ToString()
        {
            return tituloP;
        }
    }
}